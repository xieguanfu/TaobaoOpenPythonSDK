#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim: set ts=4 sts=4 sw=4 et:
'''
@author: wul
@contact: 
@date: Dec 25, 2010 10:11:34 PM
@version: 0.0.0
@license: New BSD License
'''

from DiffParserImporter import *

class DiffObject(BaseClass):
    def __init__(self):
        self.startLine = None
        self.endLine = None
        self.filename = None

    def __eq__(self, other):
        if self.startLine == other.startLine and \
            self.endLine == other.endLine and \
            self.filename == other.filename:
            return 1
        return 0