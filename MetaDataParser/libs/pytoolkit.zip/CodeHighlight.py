#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim: set ts=4 sts=4 sw=4 et:
'''
@author: garcia
@date: 2011-2-1 07:16:24
@version: 0.0.0
@license: New BSD License
'''

from BaseClass import BaseClass

class CodeHighlight(BaseClass):
    def __init__(self, **kargs):
        super(self.__class__, self).__init__(**kargs)

    def getLexer(self, code):
        from CharsetDetector import detectCharset
#        import magic
        from pygments.lexers import get_lexer_by_name

        parameters = {
            "stripall":True,
            "tabsize":4,
            'encoding':detectCharset(code)
            }
        return get_lexer_by_name("cpp", **parameters)

        #        magicInstance = magic.Magic()
        #        raw = magicInstance.from_buffer(code)
        #        if "C program" in raw:
        #            return get_lexer_by_name("cpp", **parameters)
        #        elif "python script" in raw:
        #            return get_lexer_by_name("py", **parameters)
        #        else:
        #            return get_lexer_by_name("cpp", **parameters)
        #
    def highlight(self, code, linenostart=1):
        from CharsetDetector import detectCharset
        #import magic
        from pygments.formatters.html import HtmlFormatter
        from pygments import highlight

        lexer = self.getLexer(code)
        formatter = HtmlFormatter(
            linenos=True,
            linenostart=linenostart,
            cssclass="source",
            encoding=detectCharset(code),
            outencoding='utf-8'
            )
        return highlight(code, lexer, formatter)

if __name__ == '__main__':
    import sys
    code = file(sys.argv[0]).read()
    codeHighlight = CodeHighlight()
    code = codeHighlight.highlight(code)
    print code
