#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim: set ts=4 sts=4 sw=4 et:
'''
@author: wul
@contact: 
@date: Jan 19, 2011 5:15:05 PM
@version: 0.0.0
@license: New BSD License
'''

from CSourceParserImporter import *

class EndLineFinder(BaseClass):
    def __init__(self, **kargs):
        super(self.__class__, self).__init__(**kargs)
        self.validTypes = ('class', 'function')

    def getEndLines(self):
        cfiles = self.getCFiles()
        cfileContent = dict()
        newCFiles = dict()
        for cfile, symbols in cfiles.iteritems():
            if not getIsCFile(cfile):
                continue
            newCFiles[cfile] = list()
            cfileContent[cfile] = [x.rstrip(os.linesep) for x in
                file(cfile).readlines()]
            lastStartLine = len(cfileContent[cfile])
            lastType = str()
            for symbol in symbols:
                if symbol.type not in self.validTypes:
                    continue
                # ruler 1：如果这行是类似void f() {}，那么endLine就是startLine
                line = cfileContent[cfile][symbol.startLine-1]
                if '{' in line and '}' in line and \
                    line.count('{') == line.count('}'):
                    symbol.endLine = symbol.startLine
                    newCFiles[cfile].append(symbol)
                    lastStartLine = symbol.startLine
                    lastType = symbol.type
                    self.debugMessage("%s %s %s %s matched ruler 1" %
                        (cfile, symbol.startLine, symbol.endLine, line))
                    continue

                no = symbol.startLine-1
                line = cfileContent[cfile][symbol.startLine-1]
                if line.count('{') <= 0:
                    no = symbol.startLine

                bracketNum = 0
                i = 0
                isInCommentBlock = False
                isInBlock = False
                for line in cfileContent[cfile][no:]:
                    i += 1

                    singleCommentPosition = line.find('//')
                    if singleCommentPosition == 0:
                        continue
                    elif singleCommentPosition > 0:
                        line = line[:singleCommentPosition]

                    uncommentBlockPosition = line.find('*/')
                    if uncommentBlockPosition >= 0:
                        line = line[uncommentBlockPosition+2:]
                        isInCommentBlock = False

                    commentBlockPosition = line.find('/*')
                    if commentBlockPosition >= 0:
                        isInCommentBlock = True
                    if commentBlockPosition == 0:
                        continue
                    elif commentBlockPosition > 0:
                        line = line[:commentBlockPosition]

                    if isInCommentBlock:
                        continue
                    isInBlock = line.count('{') or line.count('}') and True or \
                        False
                    bracketNum += line.count('{')
                    bracketNum -= line.count('}')
                    if bracketNum == 0 and isInBlock:
                        symbol.endLine = no + i
                        break
                if not symbol.endLine is None:
                    self.debugMessage('%s %s %s %s matched ruler 2' %
                        (cfile, symbol.startLine, symbol.endLine,
                        cfileContent[cfile][symbol.startLine-1]))
                    newCFiles[cfile].append(symbol)
                    lastStartLine = symbol.startLine
                    lastType = symbol.type
                    continue

                if lastStartLine >= symbol.startLine and \
                    symbol.type == lastType:
                    symbol.endLine = lastStartLine - 1
                    newCFiles[cfile].append(symbol)
                    lastStartLine = symbol.startLine
                    lastType = symbol.type
                    self.warnMessage('%s %s %s %s matched ruler 4' %
                        (cfile, symbol.startLine, symbol.endLine,
                        cfileContent[cfile][symbol.startLine-1]))
                else:
                    #symbol.endLine = symbol.startLine
                    symbol.endLine = len(file(cfile).readlines()) - 1 
                    newCFiles[cfile].append(symbol)
                    lastStartLine = symbol.startLine
                    lastType = symbol.type
                    self.errorMessage('%s %s %s %s matched ruler 5' %
                        (cfile, symbol.startLine, symbol.endLine,
                        cfileContent[cfile][symbol.startLine-1]))
        return newCFiles


    def getCFiles(self):
        if self.getIsValidParameter('cfiles'):
            return self.getParameterValue('cfiles')
        else:
            self.errorMessage('cfiles parameter is null')
            sys.exit(1)

if __name__ == '__main__':
    from TagsParser import TagsParser
    tagsParser = TagsParser(isDebug = True, tagsFile=sys.argv[1])
    cfiles = tagsParser.parse()
    endlineFinder = EndLineFinder(isDebug=True, cfiles=cfiles)
    cfiles = endlineFinder.getEndLines()
    for filename, symbols in cfiles.iteritems():
        print filename
        for symbol in symbols:
            print symbol.startLine,symbol.endLine,symbol.name
