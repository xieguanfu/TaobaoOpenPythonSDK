#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim: set ts=4 sts=4 sw=4 et:
'''
@author: wul
@contact: 
@date: Dec 27, 2010 7:52:32 PM
@version: 0.0.0
@license: New BSD License
'''

from BaseClass import BaseClass

class Decoder(BaseClass):
    '''
    decode任何玩意
    '''
    def __init__(self, **kargs):
        super(self.__class__, self).__init__(**kargs)
        self.__decodeDictKey = False

    def detectCharset(self, s):
        '''
        探测字符串的编码份额是
        '''
        import chardet
        return chardet.detect(str(s))['encoding']

    def decodeAny(self, any, decodeDictKey=False):
        self.__decodeDictKey = decodeDictKey
        if any is None:
            return str()

        if isinstance(any, unicode):
            return any
        if isinstance(any, str):
            any = self.decodeStr(any)
        elif isinstance(any, dict):
            any = self.decodeDict(any)
        else:
            try:
                iter(any)
            except Exception:
                any = self.decodeOther(any)
            else:
                any = self.decodeIterable(any)
        return any

    def decodeStr(self, s):
        from django.utils.encoding import force_unicode
        if s == None:
            return str()
        else:
            try:
                s = s.decode(self.detectCharset(s), errors='ignore')
            except Exception:
                s =force_unicode(s, errors='ignore')
            finally:
                return s

    def decodeIterable(self, iterable):
        return map(lambda x: self.decodeAny(x), iterable)

    def decodeDict(self, iterable):
        newDict = dict()
        for key, value in iterable.iteritems():
            if self.__decodeDictKey:
                newDict[self.decodeAny(key)] = self.decodeAny(value)
            else:
                newDict[key] = self.decodeAny(value)
        return newDict

    def decodeOther(self, s):
        from django.utils.encoding import smart_str
        s = smart_str(s, errors="ignore")
        return self.decodeStr(s)

if __name__ == '__main__':
    decoder = Decoder()
    print decoder.decodeAny("test English string")
    print decoder.decodeAny("测试中文字符串")
    anyList = ["a", 1, "b"]
    print decoder.decodeAny(anyList)
    anyDict = {"中文":"b", "c":"中文"}
    print decoder.decodeAny(anyDict)
    anyDict2 = {"a":anyList}
    print decoder.decodeAny(anyDict2)
    complex = [{'endVersion': '46534',
        u'moduleId': u'SYS/iprofile',
        }]
    print decoder.decodeAny(complex)
    print decoder.decodeAny(None)
    print decoder.decodeAny([1,2,3])