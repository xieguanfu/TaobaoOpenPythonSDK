#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim: set ts=4 sts=4 sw=4 et:
'''
@author: wul
@contact: 
@date: Dec 25, 2010 10:05:30 PM
@version: 0.0.0
@license: New BSD License
'''

from DiffParserImporter import *
from DiffObject import DiffObject

addPattern1 = re.compile('.*a(\d+),(\d+)')
addPattern2 = re.compile('.*a(\d+)')
modifyPattern1 = re.compile('.*c(\d+),(\d+)')
modifyPattern2 = re.compile('.*c(\d+)')
deletePattern1 = re.compile('.*d(\d+),(\d+)')
deletePattern2 = re.compile('.*d(\d+)')

class DiffParser(BaseClass):
    def __init__(self, **kargs):
        super(self.__class__, self).__init__(**kargs)
        self.diffFile = self.getDiffFile()

        self.diffLines = [x.rstrip(os.linesep) for x in
            file(self.diffFile).readlines()]
        self.diffObjects = list()

    def getDiffFile(self):
        if self.getIsValidParameter('diffFile'):
            diffFile = self.getParameterValue('diffFile')
            if not os.path.exists(diffFile):
                self.errorMessage("%s does not exist" % diffFile)
                sys.exit(1)
            else:
                return diffFile
        else:
            self.errorMessage('diffFile option is null')
            sys.exit(1)

    def parse(self):
        for diffLine in self.diffLines:
            if diffLine.startswith('Index:'):
                filename = diffLine.split()[1]
            elif not diffLine.startswith('<') and not diffLine.startswith('>') \
                and not diffLine.startswith('='):
                match = addPattern1.search(diffLine)
                if match:
                    diffObject = DiffObject()
                    diffObject.filename = filename
                    diffObject.startLine = int(match.groups()[0])
                    diffObject.endLine = int(match.groups()[1])
                    self.diffObjects.append(diffObject)
                    continue
                match = addPattern2.search(diffLine)
                if match:
                    diffObject = DiffObject()
                    diffObject.filename = filename
                    diffObject.startLine = int(match.groups()[0])
                    diffObject.endLine = int(match.groups()[0])
                    self.diffObjects.append(diffObject)
                    continue
                match = modifyPattern1.search(diffLine)
                if match:
                    diffObject = DiffObject()
                    diffObject.filename = filename
                    diffObject.startLine = int(match.groups()[0])
                    diffObject.endLine = int(match.groups()[1])
                    self.diffObjects.append(diffObject)
                    continue
                match = modifyPattern2.search(diffLine)
                if match:
                    diffObject = DiffObject()
                    diffObject.filename = filename
                    diffObject.startLine = int(match.groups()[0])
                    diffObject.endLine = int(match.groups()[0])
                    self.diffObjects.append(diffObject)
                    continue
                match = deletePattern1.search(diffLine)
                if match:
                    diffObject = DiffObject()
                    diffObject.filename = filename
                    diffObject.startLine = int(match.groups()[0])
                    diffObject.endLine = int(match.groups()[1])
                    self.diffObjects.append(diffObject)
                    continue
                match = deletePattern2.search(diffLine)
                if match:
                    diffObject = DiffObject()
                    diffObject.filename = filename
                    diffObject.startLine = int(match.groups()[0])
                    diffObject.endLine = int(match.groups()[0])
                    self.diffObjects.append(diffObject)
                    continue

# self test
if __name__ == '__main__':
    if len(sys.argv) < 2:
        printColorful('red', '%s diff-file' % sys.argv[0])
        sys.exit(1)

    diffParser = DiffParser(diffFile=sys.argv[1])
    diffParser.parse()
    for diffObject in diffParser.diffObjects:
        print diffObject.__dict__