#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim: set ts=4 sts=4 sw=4 et:
'''
@author: wul
@contact: 
@date: Jan 20, 2011 12:47:09 PM
@version: 0.0.0
@license: New BSD License
'''

from DiffParserImporter import *

class DiffParserExtension(BaseClass):
    def __init__(self, **kargs):
        super(self.__class__, self).__init__(**kargs)
        self.getCTagsBinary()
        self.diffObjects = self.getDiffObjects()
        self.projectPath = self.getProjectPath()
        if self.checkIsValidPath():
            self.errorMessage('%s is invaild path' % self.projectPath)
            sys.exit(1)
        self.cfiles = self.getCFiles()

    def expandDiffObject(self):
        diffObjects = list()
        for diffObject in self.diffObjects:
            filepath = os.path.join(self.projectPath, diffObject.filename)
            filepath = os.path.realpath(filepath)
            filepath = os.path.normpath(filepath)
            if not os.path.exists(filepath) or \
                not self.cfiles.has_key(filepath):
                diffObjects.append(diffObject)
                continue
            symbols = self.cfiles[filepath]
            isMatched = False
            for symbol in symbols:
                if symbol.startLine <= diffObject.startLine and \
                    symbol.endLine >= diffObject.endLine:
                    setattr(diffObject, 'filepath', filepath)
                    setattr(diffObject, 'symbol', symbol)
                    diffObjects.append(diffObject)
                    isMatched = True
                    break
            if not isMatched:
                setattr(diffObject, 'filepath', filepath)
                diffObjects.append(diffObject)
        return diffObjects

    def getCFiles(self):
        tagsGenerator = TagsGenerator(ctagsBinary=self.ctagsBinary,
            projectPath=self.projectPath)
        tagsGenerator.generateTags()
        tagsParser = TagsParser(tagsFile=tagsGenerator.tagsFile)
        cfiles = tagsParser.parse()
        endlineFinder = EndLineFinder(cfiles=cfiles)
        cfiles = endlineFinder.getEndLines()
        return cfiles

    def getDiffObjects(self):
        if self.getIsValidParameter('diffObjects'):
            return self.getParameterValue('diffObjects')
        else:
            self.errorMessage('diffObjects is null')
            sys.exit(1)

    def getProjectPath(self):
        if self.getIsValidParameter('projectPath'):
            return self.getParameterValue('projectPath')
        else:
            self.errorMessage('projectPath is null')
            sys.exit(1)

    def checkIsValidPath(self):
        counter = 0
        for diffObject in self.diffObjects:
            filepath = os.path.join(self.projectPath, diffObject.filename)
            if not os.path.exists(filepath):
                counter += 1
        return counter == len(self.diffObjects)

    def getCTagsBinary(self):
        if self.getIsValidParameter('ctagsBinary'):
            self.ctagsBinary = self.getParameterValue('ctagsBinary')
        else:
            self.ctagsBinary = None

if __name__ == '__main__':
    from DiffParser import DiffParser
    diffParser = DiffParser(diffFile=sys.argv[1], isDebug=True)
    diffParser.parse()
    diffParserExtension = DiffParserExtension(isDebug=True,
        diffObjects=diffParser.diffObjects, projectPath=sys.argv[2])
    diffObjects = diffParserExtension.expandDiffObject()
    for diffObject in diffObjects:
        print diffObject.__dict__
        if diffObject.hasAttribute('symbol'):
            print diffObject.symbol.__dict__
