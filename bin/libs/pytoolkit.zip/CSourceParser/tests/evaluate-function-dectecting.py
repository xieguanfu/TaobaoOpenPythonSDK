#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim: set ts=4 sts=4 sw=4 et:
'''
@author: wul
@contact: 
@date: Jan 19, 2011 7:21:31 PM
@version: 0.0.0
@license: New BSD License
'''

import os
import sys
currentPath = os.path.normpath(os.path.join(os.path.realpath(__file__),
    os.path.pardir))
sys.path.insert(0, os.path.join(currentPath, os.path.pardir))

from CSourceParserImporter import *
from TagsGenerator import TagsGenerator
from TagsParser import TagsParser
from EndLineFinder import EndLineFinder

if __name__ == '__main__':
    tagsGenerator = TagsGenerator(isDebug = True, projectPath=sys.argv[1])
    tagsGenerator.generateTags()
    tagsParser = TagsParser(isDebug = True, tagsFile=tagsGenerator.tagsFile)
    cfiles = tagsParser.parse()
    endlineFinder = EndLineFinder(isDebug=True, cfiles=cfiles)
    cfiles = endlineFinder.getEndLines()
    for filename, symbols in cfiles.iteritems():
        print filename
        for symbol in symbols:
            print symbol.startLine,symbol.endLine,symbol.name
    del tagsGenerator