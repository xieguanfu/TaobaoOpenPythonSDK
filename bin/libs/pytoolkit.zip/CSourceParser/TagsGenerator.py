#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim: set ts=4 sts=4 sw=4 et:
'''
@author: wul
@contact: 
@date: Jan 19, 2011 2:52:01 PM
@version: 0.0.0
@license: New BSD License
'''

from CSourceParserImporter import *

class TagsGenerator(BaseClass):
    def __init__(self, **kargs):
        super(self.__class__, self).__init__(**kargs)
        self.tagsFile = self.getTagsFile()
        self.projectPath = self.getProjectPath()
        self.getCTagsBinary()

    def __del__(self):
        try:
            if os.path.exists(self.tagsFile) and not self.isDebug:
                os.remove(self.tagsFile)
        except Exception:
            pass

    def generateTags(self):
        command = '%s --fields=afmikKlnsStz -o %s -R %s > \
            /dev/null 2>&1 < /dev/null' % (
            self.ctagsBinary, self.tagsFile, self.projectPath
            )
        self.debugMessage(command)
        os.system(command)
        self.debugMessage("Generate tags file to %s" % self.tagsFile)

    def getTagsFile(self):
        if self.getIsValidParameter('tagsFile'):
            return self.getParameterValue('tagsFile')
        else:
            return tempfile.NamedTemporaryFile(delete=False).name

    def getProjectPath(self):
        if self.getIsValidParameter('projectPath'):
            path = self.getParameterValue('projectPath')
            path = normalizePath(path)
            if not os.path.exists(path):
                self.errorMessage("%s does not exist" % path)
                sys.exit(1)
            return path
        else:
            return joinPath(os.path.realpath(__file__), os.path.pardir)

    def getCTagsBinary(self):
        if self.getIsValidParameter('ctagsBinary'):
            self.ctagsBinary = self.getParameterValue('ctagsBinary')
        else:
            self.ctagsBinary = ctagsBinary
        if not os.path.exists(self.ctagsBinary):
            self.errorMessage('%s does not exist' % self.ctagsBinary)
            sys.exit(1)

# self test
if __name__ == '__main__':
    tagsGenerator = TagsGenerator(isDebug = True, projectPath=sys.argv[1])
    print tagsGenerator.__dict__
    tagsGenerator.generateTags()