#!/usr/bin/env python

import os
import sys
currentPath = os.path.normpath(os.path.join(os.path.realpath(__file__),
    os.path.pardir))
sys.path.insert(0, os.path.join(currentPath, os.path.pardir))

from CSourceParserImporter import *
from TestEndLineFinder import TestEndLineFinder

if __name__ == '__main__':
    unittest.main()
