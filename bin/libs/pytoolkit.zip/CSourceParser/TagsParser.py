#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim: set ts=4 sts=4 sw=4 et:
'''
@author: wul
@contact: 
@date: Jan 19, 2011 4:02:06 PM
@version: 0.0.0
@license: New BSD License
'''

from CSourceParserImporter import *
from Symbol import Symbol

class TagsParser(BaseClass):
    def __init__(self, **kargs):
        super(self.__class__, self).__init__(**kargs)
        self.tagsFile = self.getTagsFile()
        self.ctagsInstance = self.getCTagsInstance()
        self.entry = TagEntry()

    def parse(self):
        cfiles = dict()
        while True:
            if self.ctagsInstance.next(self.entry) == 0:
                break
            symbol = Symbol()
            symbol.name = self.entry['name']
            symbol.type = self.entry['kind']
            symbol.startLine = self.entry['lineNumber']
            symbol.language = self.entry['language']
            filename = self.entry['file']
            if not cfiles.has_key(filename):
                cfiles[filename] = list()
                cfiles[filename].append(symbol)
            else:
                isInserted = False
                for i in range(len(cfiles[filename])):
                    if symbol.startLine > cfiles[filename][i].startLine:
                        cfiles[filename].insert(i, symbol)
                        isInserted = True
                        break
                if not isInserted:
                    cfiles[filename].append(symbol)
        return cfiles

    def getTagsFile(self):
        if self.getIsValidParameter('tagsFile'):
            path = self.getParameterValue('tagsFile')
            path = normalizePath(path)
            if not os.path.exists(path):
                self.errorMessage("%s does not exist" % path)
                sys.exit(1)
            return path

    def getCTagsInstance(self):
        try:
            tagsInstance = CTags(self.tagsFile)
        except Exception:
            self.errorMessage("Get ctags instance failed")
            sys.exit(1)
        else:
            return tagsInstance

# self test
if __name__ == '__main__':
    tagsParser = TagsParser(isDebug = True, tagsFile=sys.argv[1])
    cfiles = tagsParser.parse()
    for filename, symbols in cfiles.iteritems():
        print filename
        for symbol in symbols:
            print symbol.__dict__