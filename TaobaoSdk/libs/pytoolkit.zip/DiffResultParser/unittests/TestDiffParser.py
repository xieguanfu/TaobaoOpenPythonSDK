#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim: set ts=4 sts=4 sw=4 et:
'''
@author: wul
@contact: 
@date: Jan 19, 2011 11:46:03 PM
@version: 0.0.0
@license: New BSD License
'''

from DiffParserImporter import *
from DiffParser import DiffParser

class TestDiffParser(unittest.TestCase):
    def setUp(self):
        self.cFile = None

    def tearDown(self):
        if os.path.exists(self.diffFile):
            os.remove(self.diffFile)

    def preprocess(self):
        writeFile(self.diffFile, self.diffStr)
        self.diffParser = DiffParser(diffFile=self.diffFile)
        self.diffParser.parse()

    def testParseAddOneLine(self):
        '''
        测试44a45这样情况
        '''
        functionName = sys._getframe().f_code.co_name
        self.diffFile = os.path.join(tempfile.gettempdir(), functionName)
        self.diffStr = '''
Index: B2BSearch.h
===================================================================
44a45
>   double PredictBuy(B2BQueryInfo &queryInfo, B2BOfferInfo &offerInfo)
'''
        self.preprocess()
        actualResult = self.diffParser.diffObjects[0]
        self.assertEqual(actualResult.filename, "B2BSearch.h")
        self.assertEqual(actualResult.startLine, 45)
        self.assertEqual(actualResult.endLine, 45)

    def testParseAddMultiLines(self):
        '''
        测试44a45,100这样情况
        '''
        functionName = sys._getframe().f_code.co_name
        self.diffFile = os.path.join(tempfile.gettempdir(), functionName)
        self.diffStr = '''
Index: B2BSearch.h
===================================================================
44a45,100
>   double PredictBuy(B2BQueryInfo &queryInfo, B2BOfferInfo &offerInfo)
'''
        self.preprocess()
        actualResult = self.diffParser.diffObjects[0]
        self.assertEqual(actualResult.startLine, 45)
        self.assertEqual(actualResult.endLine, 100)

    def testParseDeleteOneLine(self):
        '''
        测试44d45这样情况
        '''
        functionName = sys._getframe().f_code.co_name
        self.diffFile = os.path.join(tempfile.gettempdir(), functionName)
        self.diffStr = '''
Index: B2BSearch.h
===================================================================
44d45
>   double PredictBuy(B2BQueryInfo &queryInfo, B2BOfferInfo &offerInfo)
'''
        self.preprocess()
        actualResult = self.diffParser.diffObjects[0]
        self.assertEqual(actualResult.filename, "B2BSearch.h")
        self.assertEqual(actualResult.startLine, 45)
        self.assertEqual(actualResult.endLine, 45)

    def testParseDeleteMultiLines(self):
        '''
        测试44d45,100这样情况
        '''
        functionName = sys._getframe().f_code.co_name
        self.diffFile = os.path.join(tempfile.gettempdir(), functionName)
        self.diffStr = '''
Index: B2BSearch.h
===================================================================
44d45,100
>   double PredictBuy(B2BQueryInfo &queryInfo, B2BOfferInfo &offerInfo)
'''
        self.preprocess()
        actualResult = self.diffParser.diffObjects[0]
        self.assertEqual(actualResult.startLine, 45)
        self.assertEqual(actualResult.endLine, 100)

    def testParseModifyOneLine(self):
        '''
        测试44c45这样情况
        '''
        functionName = sys._getframe().f_code.co_name
        self.diffFile = os.path.join(tempfile.gettempdir(), functionName)
        self.diffStr = '''
Index: B2BSearch.h
===================================================================
44c45
>   double PredictBuy(B2BQueryInfo &queryInfo, B2BOfferInfo &offerInfo)
'''
        self.preprocess()
        actualResult = self.diffParser.diffObjects[0]
        self.assertEqual(actualResult.filename, "B2BSearch.h")
        self.assertEqual(actualResult.startLine, 45)
        self.assertEqual(actualResult.endLine, 45)

    def testParseModifyMultiLines(self):
        '''
        测试44c45,100这样情况
        '''
        functionName = sys._getframe().f_code.co_name
        self.diffFile = os.path.join(tempfile.gettempdir(), functionName)
        self.diffStr = '''
Index: B2BSearch.h
===================================================================
44c45,100
>   double PredictBuy(B2BQueryInfo &queryInfo, B2BOfferInfo &offerInfo)
'''
        self.preprocess()
        actualResult = self.diffParser.diffObjects[0]
        self.assertEqual(actualResult.startLine, 45)
        self.assertEqual(actualResult.endLine, 100)
