#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim: set ts=4 sts=4 sw=4 et:
'''
@author: wul
@contact: 
@date: Jan 20, 2011 11:00:08 AM
@version: 0.0.0
@license: New BSD License
'''

import os
import sys

currentPath = os.path.normpath(os.path.join(os.path.realpath(__file__),
    os.path.pardir))
projectPath = os.path.normpath(os.path.join(currentPath, os.path.pardir))
sys.path.insert(0, projectPath)

from BaseClass import BaseClass
from Colorful import printColorful
from CSourceParser import *
import platform
import re
import tempfile
from Utility import *
import unittest