#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim: set ts=4 sts=4 sw=4 et:
'''
@author: wul
@contact: 
@date: Oct 30, 2010 2:05:02 PM
@version: 0.0.0
@license: New BSD License
'''

_FOREGROUND = {
    "black":"30",
    "red":"31",
    "green":"32",
    "yellow":"33",
    "blue":"34",
    "carmine":"35",
    "cyan":"36",
    "white":"37",
}

def getIsUseColor():
    import os
    import sys
    return (os.isatty(file.fileno(sys.stdout)) != 0 and getIsTermSupport()) and \
        (os.isatty(file.fileno(sys.stderr)) != 0 and getIsTermSupport())

def getIsTermSupport():
    import os
    term = os.getenv("TERM");
    return term == "xterm" or term == "xterm-color" or \
        term == "xterm-256color" or term == "linux" or term == "cygwin"

def printColorful(color, *strings, **kargs):
    '''
    使用彩色的输出
    @param color: 使用什么颜色，目前支持的颜色有：black red green yellow blue carmine cyan white
    @param *strings: 需要输出的字符串
    @param **kargs: 可选的参数，目前只有outputStream这一项，可以选择是sys.stdout还是sys.stderr。默认是sys.stdout
    '''
    import os
    import sys

    # 得到是否使用彩色打印
    isUseColor = getIsUseColor()
    if color not in _FOREGROUND.keys():
        isUseColor = False

    # 得到输出流
    outputStream = sys.stdout
    if kargs.has_key("outputStream") and kargs["outputStream"] == sys.stderr:
        outputStream = sys.stderr

    if isUseColor:
        outputStream.write("\033[1;%sm" % _FOREGROUND[color])
    for s in strings:
        outputStream.write(str(s))
    if isUseColor:
        outputStream.write("\033[m");
    outputStream.write(os.linesep)

def coloredString(color, s):
    colors = {
        "black":"30",
        "red":"31",
        "green":"32",
        "yellow":"33",
        "blue":"34",
        "carmine":"35",
        "cyan":"36",
        "white":"37",
    }
    isUseColor = getIsUseColor()
    if color not in colors.keys():
        isUseColor = False
    if isUseColor:
        return '\033[1;%sm%s\033[m' % (colors[color], str(s))
    else:
        return s

if __name__ == '__main__':
    import sys

    s = "Hello World!"
    printColorful("green", s, 1, " hi!", outputStream=sys.stderr)